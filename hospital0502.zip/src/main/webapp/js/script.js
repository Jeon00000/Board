$(function(){

  //banner slide
  $('.left-nav').hover(function(){
    $('.under-nav').stop().slideToggle(700);
});
$('.under-nav').hover(function(){
    $('.under-nav').stop().slideToggle(1000);
});
    
    //main pop slide

    setInterval(myslide,3000);
    function myslide(){
      $('.slide').animate({
        'left': '-210px'
      },3000, function(){
        $('.slide img:first-child')
        .clone().appendTo('.slide');
        $('.slide img:first-child').remove();
        $('.slide').css('left',0);
      })
    }
    
   filterSelection("total");
});//Jquery



function fadeInOut(){
    $('.slider img:eq(0)')
    .fadeOut(500).next()
    .fadeIn(500).end()
    .appendTo('.slider');
}

//main tab

$('.tab a').click(function(e){
  e.preventDefault();
  $('.tab a').removeClass('active');
  $(this).addClass('active');
  const myid = $(this).data("idx");
  $('.tab-content>div').removeClass('active');
  $(myid).addClass('active');
});
  
  
  
  //item js
  
  function filterSelection(c) {
    $(".filtert").removeClass("show");
    if (c == "total") {
      $(".filtert").addClass("show");
    } else {
      $(".filtert." + c).addClass("show");
    }
  }
  